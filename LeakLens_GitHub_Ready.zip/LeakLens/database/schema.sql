CREATE DATABASE leaklens;

-- Run the following tables after connecting to the leaklens database.

CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    category VARCHAR(80) NOT NULL,
    purchase_price NUMERIC(10,2) NOT NULL CHECK (purchase_price >= 0),
    selling_price NUMERIC(10,2) NOT NULL CHECK (selling_price >= 0),
    current_stock INTEGER NOT NULL DEFAULT 0 CHECK (current_stock >= 0),
    reorder_level INTEGER NOT NULL DEFAULT 5 CHECK (reorder_level >= 0),
    expiry_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sales (
    id SERIAL PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    total_amount NUMERIC(10,2) NOT NULL,
    sold_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS wastage (
    id SERIAL PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    reason VARCHAR(200) NOT NULL,
    wasted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS purchases (
    id SERIAL PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    purchase_price NUMERIC(10,2) NOT NULL,
    purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO products
(name, category, purchase_price, selling_price, current_stock, reorder_level, expiry_date)
VALUES
('Milk 500ml', 'Dairy', 25, 32, 18, 10, CURRENT_DATE + INTERVAL '2 days'),
('Bread', 'Bakery', 30, 40, 7, 8, CURRENT_DATE + INTERVAL '1 day'),
('Biscuits', 'Snacks', 12, 20, 35, 10, CURRENT_DATE + INTERVAL '90 days'),
('Cooking Oil 1L', 'Grocery', 110, 135, 4, 6, CURRENT_DATE + INTERVAL '180 days'),
('Curd 500g', 'Dairy', 35, 45, 3, 8, CURRENT_DATE - INTERVAL '1 day')
ON CONFLICT DO NOTHING;
