import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import './style.css'

const API = 'http://127.0.0.1:8000'

function App() {
  const [dashboard, setDashboard] = useState(null)
  const [products, setProducts] = useState([])
  const [error, setError] = useState('')

  async function load() {
    try {
      setError('')
      const [d, p] = await Promise.all([
        fetch(`${API}/api/dashboard`),
        fetch(`${API}/api/products`)
      ])
      if (!d.ok || !p.ok) throw new Error('Backend is not reachable')
      setDashboard(await d.json())
      setProducts(await p.json())
    } catch (e) {
      setError('Start the FastAPI backend to load live data.')
    }
  }

  useEffect(() => { load() }, [])

  return (
    <div className="app">
      <header>
        <div>
          <p className="tag">SMALL BUSINESS PROFIT INTELLIGENCE</p>
          <h1>LeakLens</h1>
          <p>Hidden Loss Detector</p>
        </div>
        <button onClick={load}>Refresh</button>
      </header>

      {error && <div className="error">{error}</div>}

      <section className="hero">
        <h2>Find where your profit is leaking.</h2>
        <p>Track wastage, expired stock, low inventory and hidden operational losses from one dashboard.</p>
      </section>

      <section className="cards">
        <Card title="Inventory Value" value={dashboard ? `₹${dashboard.inventory_value.toFixed(2)}` : '—'} />
        <Card title="Sales Revenue" value={dashboard ? `₹${dashboard.sales_revenue.toFixed(2)}` : '—'} />
        <Card title="Wastage Loss" value={dashboard ? `₹${dashboard.wastage_loss.toFixed(2)}` : '—'} />
        <Card title="Low Stock" value={dashboard?.low_stock_count ?? '—'} />
        <Card title="Expired" value={dashboard?.expired_count ?? '—'} />
      </section>

      <div className="grid">
        <section className="panel">
          <h2>Inventory</h2>
          <table>
            <thead><tr><th>Product</th><th>Category</th><th>Stock</th><th>Expiry</th></tr></thead>
            <tbody>
              {products.map(p => (
                <tr key={p.id}>
                  <td>{p.name}</td>
                  <td>{p.category}</td>
                  <td className={p.current_stock <= p.reorder_level ? 'warning' : ''}>{p.current_stock}</td>
                  <td>{p.expiry_date || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section className="panel">
          <h2>Smart Alerts</h2>
          {dashboard?.alerts?.length ? dashboard.alerts.map((a, i) => (
            <div className="alert" key={i}>
              <strong>{a.type}</strong>
              <span>{a.product} · Stock: {a.stock}</span>
            </div>
          )) : <p className="muted">No active alerts.</p>}
        </section>
      </div>
    </div>
  )
}

function Card({ title, value }) {
  return <div className="card"><span>{title}</span><strong>{value}</strong></div>
}

createRoot(document.getElementById('root')).render(<App />)
