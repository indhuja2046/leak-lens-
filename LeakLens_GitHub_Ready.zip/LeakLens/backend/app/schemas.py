from datetime import date
from decimal import Decimal
from pydantic import BaseModel, ConfigDict

class ProductCreate(BaseModel):
    name: str
    category: str
    purchase_price: Decimal
    selling_price: Decimal
    current_stock: int = 0
    reorder_level: int = 5
    expiry_date: date | None = None

class ProductOut(ProductCreate):
    id: int
    model_config = ConfigDict(from_attributes=True)

class SaleCreate(BaseModel):
    product_id: int
    quantity: int

class WastageCreate(BaseModel):
    product_id: int
    quantity: int
    reason: str
