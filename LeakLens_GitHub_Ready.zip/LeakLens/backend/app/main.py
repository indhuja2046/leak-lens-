from datetime import date
from decimal import Decimal
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func

from .database import Base, engine, get_db
from .models import Product, Sale, Wastage, Purchase
from .schemas import ProductCreate, ProductOut, SaleCreate, WastageCreate

Base.metadata.create_all(bind=engine)

app = FastAPI(title="LeakLens API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"message": "LeakLens API is running"}

@app.get("/api/products", response_model=list[ProductOut])
def products(db: Session = Depends(get_db)):
    return db.query(Product).order_by(Product.id).all()

@app.post("/api/products", response_model=ProductOut)
def create_product(data: ProductCreate, db: Session = Depends(get_db)):
    product = Product(**data.model_dump())
    db.add(product)
    db.commit()
    db.refresh(product)
    return product

@app.post("/api/sales")
def create_sale(data: SaleCreate, db: Session = Depends(get_db)):
    product = db.get(Product, data.product_id)
    if not product:
        raise HTTPException(404, "Product not found")
    if data.quantity > product.current_stock:
        raise HTTPException(400, "Insufficient stock")
    sale = Sale(
        product_id=product.id,
        quantity=data.quantity,
        total_amount=product.selling_price * data.quantity
    )
    product.current_stock -= data.quantity
    db.add(sale)
    db.commit()
    return {"message": "Sale recorded", "total_amount": float(sale.total_amount)}

@app.post("/api/wastage")
def create_wastage(data: WastageCreate, db: Session = Depends(get_db)):
    product = db.get(Product, data.product_id)
    if not product:
        raise HTTPException(404, "Product not found")
    if data.quantity > product.current_stock:
        raise HTTPException(400, "Insufficient stock")
    item = Wastage(**data.model_dump())
    product.current_stock -= data.quantity
    db.add(item)
    db.commit()
    return {"message": "Wastage recorded"}

@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db)):
    products = db.query(Product).all()
    sales = db.query(func.coalesce(func.sum(Sale.total_amount), 0)).scalar()
    wastage_cost = db.query(
        func.coalesce(func.sum(Wastage.quantity * Product.purchase_price), 0)
    ).join(Product, Wastage.product_id == Product.id).scalar()

    low_stock = [p for p in products if p.current_stock <= p.reorder_level]
    expired = [
        p for p in products
        if p.expiry_date and p.expiry_date < date.today() and p.current_stock > 0
    ]
    expiring_soon = [
        p for p in products
        if p.expiry_date and 0 <= (p.expiry_date - date.today()).days <= 7
        and p.current_stock > 0
    ]

    inventory_value = sum(
        Decimal(str(p.purchase_price)) * p.current_stock for p in products
    )

    return {
        "total_products": len(products),
        "inventory_value": float(inventory_value),
        "sales_revenue": float(sales or 0),
        "wastage_loss": float(wastage_cost or 0),
        "low_stock_count": len(low_stock),
        "expired_count": len(expired),
        "expiring_soon_count": len(expiring_soon),
        "alerts": [
            {"type": "Low Stock", "product": p.name, "stock": p.current_stock}
            for p in low_stock
        ] + [
            {"type": "Expired", "product": p.name, "stock": p.current_stock}
            for p in expired
        ] + [
            {"type": "Expiring Soon", "product": p.name, "stock": p.current_stock}
            for p in expiring_soon
        ]
    }
