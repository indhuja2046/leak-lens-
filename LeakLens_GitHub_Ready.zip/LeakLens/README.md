# LeakLens – Hidden Loss Detector

LeakLens is a full-stack inventory and sales analytics application for small shops. It helps identify hidden profit losses caused by wastage, expired stock, slow-moving inventory, and unnecessary purchases.

## Features
- Product and inventory management
- Sales recording
- Wastage tracking
- Expired-stock detection
- Low-stock and over-purchase alerts
- Hidden-loss dashboard
- REST API with FastAPI
- PostgreSQL database
- React + Vite frontend

## Tech Stack
- Frontend: React, Vite, JavaScript, CSS
- Backend: Python, FastAPI, SQLAlchemy
- Database: PostgreSQL

## Project Structure
```text
LeakLens/
├── frontend/
├── backend/
├── database/
└── README.md
```

## 1. PostgreSQL setup
Create a database named `leaklens`.

Then run:
```sql
\i database/schema.sql
```

Or copy the SQL from `database/schema.sql` into pgAdmin Query Tool.

## 2. Backend
Open a terminal in `backend`:
```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Install:
```bash
pip install -r requirements.txt
```

Create `.env` from `.env.example` and update your PostgreSQL username/password.

Run:
```bash
uvicorn app.main:app --reload
```

Backend:
http://127.0.0.1:8000

API documentation:
http://127.0.0.1:8000/docs

## 3. Frontend
Open another terminal in `frontend`:
```bash
npm install
npm run dev
```

Frontend:
http://localhost:5173

## GitHub
After extracting the ZIP:
```bash
git init
git add .
git commit -m "Initial LeakLens project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```
